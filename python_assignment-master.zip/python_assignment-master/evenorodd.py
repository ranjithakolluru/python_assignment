a=int(raw_input("enter a number"))

if (a % 2==0 and a % 4 ==0 ):
                             print "even no. and a multiple of 4"
 
                             print "odd no., not a multiple of 4 and check doesnot divides evenly into num "
   