import classMovies
Ava=classMovies.movies('Avengers','2:00','ActionMovie','English')
Bah=classMovies.movies('Bahubali','3:00','ActionMovie','Telugu')
Bat=classMovies.movies('Batman','2:00','ActionMovie','English')


Bah.displaymovies()
Bah.famous()
Bah.croresTurnover()