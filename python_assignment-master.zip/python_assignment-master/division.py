num=int(raw_input("enter a no."))
check=int(raw_input("enter other number to divide"))

if(num % check==0):
    print " check divides evenly into num" 
else:
    print "doesnot divide evenly"                                         
                             
