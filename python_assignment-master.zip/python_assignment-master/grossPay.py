a=int(raw_input("enter no. of hours"))
b=float(raw_input("rate per hour"))
grosspay=float(a)*float(b) 
print grosspay