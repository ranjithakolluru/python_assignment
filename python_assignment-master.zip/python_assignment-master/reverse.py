# reverse split
name=raw_input("enter any sentence:")
s=name.split(' ')
v=s[::-1]
print " ".join(v)

