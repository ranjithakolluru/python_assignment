#OmitFirstChar and ConcatStrings
str1=raw_input("enter first string")
str2=raw_input("enter second string")
v=str1[1:] + str2[1:]
print v