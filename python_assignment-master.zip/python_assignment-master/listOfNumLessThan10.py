a=[1,2,2,3,4,55,65,76,78]
for i in range(len(a)):
    if a[i]<10:
        print "less than 10 are",a[i]



a=[1,2,2,3,4,55,65,76,78]
x=input("enter a number")
for i in range(len(a)):
    if a[i]<x:
        print a[i]