import ParentChildClass
Bahubali=ParentChildClass.movies("Bahubali2","3:00","story of war and love","https://www.youtube.com/watch?v=qD-6d8Wo3do","https://www.desiretrees.in/wp-content/uploads/2017/02/Baahubali-2-New-Poster-Maha-Shivaratri.jpg")

Bahubali.open_video()
print Bahubali.Title
Flash=ParentChildClass.TvShows("Flash","45","1","3","https://youtu.be/Yj0l7iGKh8g")
print Flash.Run_time
