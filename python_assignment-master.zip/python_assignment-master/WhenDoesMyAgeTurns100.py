import datetime 
name=raw_input("enter your name")
age=input("enter your age")
cy=datetime.datetime.today().year
b=100-age
r=cy+b
print name + " will turn 100 in the year" , r